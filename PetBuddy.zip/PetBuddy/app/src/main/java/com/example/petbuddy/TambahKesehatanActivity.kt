package com.example.petbuddy

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class TambahKesehatanActivity : AppCompatActivity() {

    private lateinit var etNamaHewan: EditText
    private lateinit var etJenisPemeriksaan: EditText
    private lateinit var etTanggal: EditText
    private lateinit var etKeterangan: EditText
    private lateinit var btnSimpan: Button

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tambah_kesehatan)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        etNamaHewan = findViewById(R.id.etNamaHewan)
        etJenisPemeriksaan = findViewById(R.id.etJenisPemeriksaan)
        etTanggal = findViewById(R.id.etTanggal)
        etKeterangan = findViewById(R.id.etKeterangan)
        btnSimpan = findViewById(R.id.btnSimpanKesehatan)

        btnSimpan.setOnClickListener { simpanData() }
    }

    private fun simpanData() {
        val userId = auth.currentUser?.uid ?: return

        val nama = etNamaHewan.text.toString()
        val jenis = etJenisPemeriksaan.text.toString()
        val tanggal = etTanggal.text.toString()
        val ket = etKeterangan.text.toString()

        if (nama.isEmpty() || jenis.isEmpty() || tanggal.isEmpty()) {
            Toast.makeText(this, "Isi data dengan benar", Toast.LENGTH_SHORT).show()
            return
        }

        val docRef = db.collection("kesehatan").document()

        val data = Kesehatan(
            id = docRef.id,
            namaHewan = nama,
            jenisPemeriksaan = jenis,
            tanggal = tanggal,
            keterangan = ket,
            userId = userId
        )

        docRef.set(data)
            .addOnSuccessListener {
                Toast.makeText(this, "Berhasil ditambahkan", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Gagal menyimpan", Toast.LENGTH_SHORT).show()
            }
    }
}
