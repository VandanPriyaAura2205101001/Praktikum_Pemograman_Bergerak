package com.example.petbuddy

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.petbuddy.adapter.PetAdapter
import com.example.petbuddy.model.Pet

class PetListActivity : AppCompatActivity() {

    private lateinit var rvPetList: RecyclerView
    private lateinit var btnAddPet: Button

    private val petList = mutableListOf<Pet>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pet_list)

        rvPetList = findViewById(R.id.rvPetList)
        btnAddPet = findViewById(R.id.btnAddPet)

        rvPetList.layoutManager = LinearLayoutManager(this)

        // Data awal kucing & anjing
        petList.add(Pet("Kucing Persia", "Kucing berbulu lebat dan jinak", R.drawable.ic_cat))
        petList.add(Pet("Anjing Husky", "Anjing kuat & aktif", R.drawable.ic_dog))

        rvPetList.adapter = PetAdapter(petList) {}

        btnAddPet.setOnClickListener {
            // nanti kalau activity tambah mau dibuat, tinggal aktifkan
            // startActivity(Intent(this, AddPetActivity::class.java))
        }
    }
}
