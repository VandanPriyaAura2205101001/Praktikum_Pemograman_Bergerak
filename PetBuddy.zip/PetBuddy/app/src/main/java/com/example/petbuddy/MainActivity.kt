package com.example.petbuddy

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    // Views
    private lateinit var tvGreeting: TextView
    private lateinit var tvTotalPets: TextView
    private lateinit var tvUpcomingCare: TextView
    private lateinit var tvHealthCheck: TextView
    private lateinit var menuPetData: com.google.android.material.card.MaterialCardView
    private lateinit var menuCare: com.google.android.material.card.MaterialCardView
    private lateinit var menuHealth: com.google.android.material.card.MaterialCardView
    private lateinit var menuProfile: com.google.android.material.card.MaterialCardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = Firebase.auth
        db = FirebaseFirestore.getInstance()

        // Check if user is logged in, if not redirect to Login
        checkUserAuthentication()
        initViews()
        setupClickListeners()
        setupUI()
    }

    private fun checkUserAuthentication() {
        val currentUser = auth.currentUser

        if (currentUser == null) {
            // User not logged in, redirect to LoginActivity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun initViews() {
        tvGreeting = findViewById(R.id.tvGreeting)
        tvTotalPets = findViewById(R.id.tvTotalPets)
        tvUpcomingCare = findViewById(R.id.tvUpcomingCare)
        tvHealthCheck = findViewById(R.id.tvHealthCheck)
        menuPetData = findViewById(R.id.menuPetData)
        menuCare = findViewById(R.id.menuCare)
        menuHealth = findViewById(R.id.menuHealth)
        menuProfile = findViewById(R.id.menuProfile)
    }

    private fun setupClickListeners() {
        // Menu items
        menuPetData.setOnClickListener {
            val intent = Intent(this, DataHewanActivity::class.java)
            startActivity(intent)
        }

        menuCare.setOnClickListener {
            val intent = Intent(this, PerawatanActivity::class.java)
            startActivity(intent)
        }

        menuHealth.setOnClickListener {
            val intent = Intent(this, KesehatanActivity::class.java)
            startActivity(intent)
        }

        menuProfile.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setupUI() {
        val currentUser = auth.currentUser
        val userName = currentUser?.email?.substringBefore("@") ?: "PetLovers"
        tvGreeting.text = "Halo, $userName!"

        tvTotalPets.text = "0"
        tvUpcomingCare.text = "0"
        tvHealthCheck.text = "0"

        val userId = currentUser?.uid ?: return

        // Listener hewan
        db.collection("hewan")
            .whereEqualTo("userId", userId)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    tvTotalPets.text = "0"
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    val totalHewan = snapshots.size()
                    tvTotalPets.text = totalHewan.toString()
                }
            }

        // Listener perawatan → AGAR MATERIAL CARD TERUPDATE
        db.collection("perawatan")
            .whereEqualTo("userId", userId)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    tvUpcomingCare.text = "0"
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    val totalPerawatan = snapshots.size()
                    tvUpcomingCare.text = totalPerawatan.toString()
                }
            }

        // Listener kesehatan → update card kesehatan di dashboard
        db.collection("kesehatan")
            .whereEqualTo("userId", userId)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    tvHealthCheck.text = "0"
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    val totalHealth = snapshots.size()
                    tvHealthCheck.text = totalHealth.toString()
                }
            }
    }


    // Handle back button to exit app
    override fun onBackPressed() {
        finishAffinity()
    }
}
