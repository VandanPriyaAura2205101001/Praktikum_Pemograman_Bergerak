package com.example.petbuddy.utils

import android.util.Patterns

object ValidationUtils {

    fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun isValidPassword(password: String): Boolean {
        return password.length >= 6
    }

    fun isValidName(name: String): Boolean {
        return name.length >= 2 && name.matches(Regex("^[a-zA-Z\\s]+$"))
    }

    // TAMBAH FUNGSI VALIDASI NOMOR TELEPON
    fun isValidPhone(phone: String): Boolean {
        // Validasi nomor telepon Indonesia
        // Format: +62, 62, 08, atau 8 diikuti 9-13 digit
        val phoneRegex = Regex("^(\\+62|62|0)8[1-9][0-9]{6,9}\$")
        return phoneRegex.matches(phone.replace("\\s".toRegex(), ""))
    }

    fun doPasswordsMatch(password: String, confirmPassword: String): Boolean {
        return password == confirmPassword
    }

    fun isFieldEmpty(field: String): Boolean {
        return field.trim().isEmpty()
    }
}