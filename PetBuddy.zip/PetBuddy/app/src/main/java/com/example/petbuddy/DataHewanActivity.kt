package com.example.petbuddy

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

data class Hewan(
    val id: String = "",
    val nama: String = "",
    val jenis: String = "",
    val umur: Int = 0
)

class DataHewanActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    private lateinit var rvHewan: RecyclerView
    private lateinit var btnTambahHewan: Button
    private lateinit var adapter: HewanAdapter
    private var hewanList = mutableListOf<Hewan>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_hewan)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        rvHewan = findViewById(R.id.rvHewan)
        btnTambahHewan = findViewById(R.id.btnTambahHewan)

        // ====== DIGANTI (tanpa mengubah kode lain) ======
        adapter = HewanAdapter(hewanList) { hewan, position ->

            AlertDialog.Builder(this)
                .setTitle("Hapus Hewan")
                .setMessage("Yakin ingin menghapus ${hewan.nama}?")
                .setPositiveButton("Hapus") { _, _ ->
                    db.collection("hewan")
                        .document(hewan.id)
                        .delete()
                        .addOnSuccessListener {
                            hewanList.removeAt(position)
                            adapter.notifyItemRemoved(position)
                            adapter.notifyItemRangeChanged(position, hewanList.size)
                            Toast.makeText(this, "Hewan dihapus", Toast.LENGTH_SHORT).show()
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "Gagal menghapus hewan", Toast.LENGTH_SHORT).show()
                        }
                }
                .setNegativeButton("Batal", null)
                .show()
        }
        // ===============================================

        rvHewan.layoutManager = LinearLayoutManager(this)
        rvHewan.adapter = adapter

        loadHewan()

        btnTambahHewan.setOnClickListener {
            showTambahHewanDialog()
        }
    }

    private fun loadHewan() {
        val userId = auth.currentUser?.uid ?: return

        db.collection("hewan")
            .whereEqualTo("userId", userId)
            .get()
            .addOnSuccessListener { documents ->
                hewanList.clear()
                for (doc in documents) {
                    val hewan = Hewan(
                        id = doc.id,
                        nama = doc.getString("nama") ?: "",
                        jenis = doc.getString("jenis") ?: "",
                        umur = doc.getLong("umur")?.toInt() ?: 0
                    )
                    hewanList.add(hewan)
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Gagal memuat data hewan", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showTambahHewanDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Tambah Hewan")

        val view = LayoutInflater.from(this).inflate(R.layout.dialog_tambah_hewan, null)
        val etNama = view.findViewById<EditText>(R.id.etNamaHewan)
        val etJenis = view.findViewById<EditText>(R.id.etJenisHewan)
        val etUmur = view.findViewById<EditText>(R.id.etUmurHewan)

        builder.setView(view)
        builder.setPositiveButton("Simpan") { _, _ ->
            val nama = etNama.text.toString().trim()
            val jenis = etJenis.text.toString().trim()
            val umur = etUmur.text.toString().trim().toIntOrNull() ?: 0

            if (nama.isNotEmpty() && jenis.isNotEmpty()) {
                tambahHewan(nama, jenis, umur)
            } else {
                Toast.makeText(this, "Semua field harus diisi", Toast.LENGTH_SHORT).show()
            }
        }
        builder.setNegativeButton("Batal", null)
        builder.show()
    }

    private fun tambahHewan(nama: String, jenis: String, umur: Int) {
        val userId = auth.currentUser?.uid ?: return
        val data = hashMapOf(
            "userId" to userId,
            "nama" to nama,
            "jenis" to jenis,
            "umur" to umur
        )

        db.collection("hewan")
            .add(data)
            .addOnSuccessListener {
                Toast.makeText(this, "Hewan berhasil ditambahkan", Toast.LENGTH_SHORT).show()
                loadHewan()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Gagal menambahkan hewan", Toast.LENGTH_SHORT).show()
            }
    }
}
