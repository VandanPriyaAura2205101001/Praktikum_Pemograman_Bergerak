package com.example.petbuddy

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HewanAdapter(
    private val hewanList: List<Hewan>,
    private val onHapusClick: (Hewan, Int) -> Unit // ← DITAMBAHKAN
) :
    RecyclerView.Adapter<HewanAdapter.HewanViewHolder>() {

    inner class HewanViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNama: TextView = itemView.findViewById(R.id.tvNamaHewan)
        val tvJenis: TextView = itemView.findViewById(R.id.tvJenisHewan)
        val tvUmur: TextView = itemView.findViewById(R.id.tvUmurHewan)
        val btnHapus: Button = itemView.findViewById(R.id.btnHapus) // ← DITAMBAHKAN
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HewanViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_hewan, parent, false)
        return HewanViewHolder(view)
    }

    override fun onBindViewHolder(holder: HewanViewHolder, position: Int) {
        val hewan = hewanList[position]
        holder.tvNama.text = hewan.nama
        holder.tvJenis.text = hewan.jenis
        holder.tvUmur.text = "Umur: ${hewan.umur} tahun"

        holder.btnHapus.setOnClickListener { // ← DITAMBAHKAN
            onHapusClick(hewan, position)
        }
    }

    override fun getItemCount(): Int = hewanList.size
}
