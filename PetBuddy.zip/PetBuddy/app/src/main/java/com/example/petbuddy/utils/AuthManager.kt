package com.example.petbuddy.utils

import android.content.Context
import android.util.Log
import com.example.petbuddy.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.tasks.await

class AuthManager(private val context: Context) {

    private val auth: FirebaseAuth = Firebase.auth
    private val db: FirebaseFirestore = Firebase.firestore

    companion object {
        private const val TAG = "AuthManager"
        private const val USERS_COLLECTION = "users"
    }

    // Check if user is logged in
    val isUserLoggedIn: Boolean
        get() = auth.currentUser != null

    // Get current user from Firebase Auth
    val currentUser get() = auth.currentUser

    // Get current user ID
    val currentUserId: String?
        get() = auth.currentUser?.uid

    // Register with email and password
    suspend fun register(
        fullName: String,
        email: String,
        password: String
    ): Result<User> {
        return try {
            Log.d(TAG, "Starting registration for: $email")

            // Create user in Firebase Auth
            val authResult = auth.createUserWithEmailAndPassword(email, password).await()

            val user = authResult.user ?: throw Exception("User creation failed")

            // Update profile with display name
            val profileUpdates = UserProfileChangeRequest.Builder()
                .setDisplayName(fullName)
                .build()

            user.updateProfile(profileUpdates).await()

            // Create user document in Firestore
            val newUser = User(
                uid = user.uid,
                fullName = fullName,
                email = email,
                phone = "",
                bio = "Pengguna PetBuddy yang menyayangi hewan 🐾"
            )

            saveUserToFirestore(newUser)
            Log.d(TAG, "Registration successful for: $email")
            Result.success(newUser)
        } catch (e: Exception) {
            Log.e(TAG, "Register error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // Login with email and password
    suspend fun login(email: String, password: String): Result<Boolean> {
        return try {
            Log.d(TAG, "Attempting login for: $email")
            val authResult = auth.signInWithEmailAndPassword(email, password).await()
            val success = authResult.user != null
            if (success) {
                Log.d(TAG, "Login successful for: $email")
            } else {
                Log.w(TAG, "Login failed for: $email")
            }
            Result.success(success)
        } catch (e: Exception) {
            Log.e(TAG, "Login error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // Save user to Firestore
    private suspend fun saveUserToFirestore(user: User): Result<Boolean> {
        return try {
            db.collection(USERS_COLLECTION)
                .document(user.uid)
                .set(user.toMap())
                .await()
            Log.d(TAG, "User saved to Firestore: ${user.uid}")
            Result.success(true)
        } catch (e: Exception) {
            Log.e(TAG, "Save user error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // Get user data from Firestore
    suspend fun getUserData(uid: String): Result<User> {
        return try {
            Log.d(TAG, "Fetching user data for: $uid")
            val document = db.collection(USERS_COLLECTION)
                .document(uid)
                .get()
                .await()

            if (document.exists()) {
                val user = User.fromMap(document.data!!)
                Log.d(TAG, "User data fetched successfully: $uid")
                Result.success(user)
            } else {
                Log.w(TAG, "User document not found: $uid")
                Result.failure(Exception("User document not found"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Get user data error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // Get current user data
    suspend fun getCurrentUserData(): Result<User> {
        return currentUserId?.let { uid ->
            getUserData(uid)
        } ?: Result.failure(Exception("No user logged in"))
    }

    // Update user profile
    suspend fun updateUserProfile(user: User): Result<Boolean> {
        return try {
            Log.d(TAG, "Updating profile for: ${user.uid}")

            // Update in Firestore
            db.collection(USERS_COLLECTION)
                .document(user.uid)
                .set(user.toMap())
                .await()

            // Update in Firebase Auth profile
            val currentUser = auth.currentUser
            if (currentUser != null) {
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(user.fullName)
                    .build()
                currentUser.updateProfile(profileUpdates).await()
            }

            Log.d(TAG, "Profile updated successfully: ${user.uid}")
            Result.success(true)
        } catch (e: Exception) {
            Log.e(TAG, "Update profile error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // Send password reset email
    suspend fun sendPasswordResetEmail(email: String): Result<Boolean> {
        return try {
            Log.d(TAG, "Sending password reset email to: $email")
            auth.sendPasswordResetEmail(email).await()
            Log.d(TAG, "Password reset email sent successfully")
            Result.success(true)
        } catch (e: Exception) {
            Log.e(TAG, "Password reset error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // Logout
    fun logout() {
        Log.d(TAG, "Logging out user")
        auth.signOut()
    }

    // Delete user account
    suspend fun deleteAccount(): Result<Boolean> {
        return try {
            val user = auth.currentUser
            user?.delete()?.await()
            Log.d(TAG, "User account deleted")
            Result.success(true)
        } catch (e: Exception) {
            Log.e(TAG, "Delete account error: ${e.message}", e)
            Result.failure(e)
        }
    }
}