package com.example.petbuddy

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class KesehatanActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var rvKesehatan: RecyclerView
    private lateinit var fabAdd: FloatingActionButton
    private lateinit var adapter: KesehatanAdapter
    private val listKesehatan = mutableListOf<Kesehatan>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kesehatan)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        rvKesehatan = findViewById(R.id.rvKesehatan)
        fabAdd = findViewById(R.id.fabAddKesehatan)

        adapter = KesehatanAdapter(listKesehatan)
        rvKesehatan.layoutManager = LinearLayoutManager(this)
        rvKesehatan.adapter = adapter

        fabAdd.setOnClickListener {
            startActivity(Intent(this, TambahKesehatanActivity::class.java))
        }

        loadData()
    }

    // ➕ DITAMBAHKAN AGAR DATA LANGSUNG REFRESH SETELAH MENAMBAH
    override fun onResume() {
        super.onResume()
        loadData()               // refresh data terbaru
        adapter.notifyDataSetChanged()   // langsung update RecyclerView
    }

    private fun loadData() {
        val userId = auth.currentUser?.uid ?: return

        db.collection("kesehatan")
            .whereEqualTo("userId", userId)
            .get()
            .addOnSuccessListener { result ->
                listKesehatan.clear()
                for (doc in result) {
                    val data = doc.toObject(Kesehatan::class.java)
                    listKesehatan.add(data)
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Gagal memuat data", Toast.LENGTH_SHORT).show()
            }
    }
}
