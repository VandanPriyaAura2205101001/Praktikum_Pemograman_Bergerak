package com.example.petbuddy.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.petbuddy.R
import com.example.petbuddy.model.Pet

class PetAdapter(
    private val petList: List<Pet>,
    private val onClick: (Pet) -> Unit
) : RecyclerView.Adapter<PetAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgPet: ImageView = view.findViewById(R.id.imgPet)
        val txtName: TextView = view.findViewById(R.id.txtPetName)
        val txtDesc: TextView = view.findViewById(R.id.txtPetDesc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pet, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = petList.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val pet = petList[position]
        holder.imgPet.setImageResource(pet.imageRes)
        holder.txtName.text = pet.name
        holder.txtDesc.text = pet.description

        holder.itemView.setOnClickListener {
            onClick(pet)
        }
    }
}
