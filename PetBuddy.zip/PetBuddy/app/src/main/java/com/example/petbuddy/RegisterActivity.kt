package com.example.petbuddy

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.petbuddy.utils.ValidationUtils
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var etFullName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPhone: EditText // TAMBAH INI
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var cbTerms: CheckBox
    private lateinit var btnRegister: Button
    private lateinit var btnBack: ImageButton
    private lateinit var tvLogin: TextView

    // Firestore database
    private val db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        auth = Firebase.auth

        initViews()
        setupClickListeners()
    }

    private fun initViews() {
        etFullName = findViewById(R.id.etFullName)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone) // TAMBAH INI
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        cbTerms = findViewById(R.id.cbTerms)
        btnRegister = findViewById(R.id.btnRegister)
        btnBack = findViewById(R.id.btnBack)
        tvLogin = findViewById(R.id.tvLogin)
    }

    private fun setupClickListeners() {
        btnRegister.setOnClickListener {
            registerUser()
        }

        btnBack.setOnClickListener {
            onBackPressed()
        }

        tvLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    private fun registerUser() {
        val fullName = etFullName.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val phone = etPhone.text.toString().trim() // TAMBAH INI
        val password = etPassword.text.toString().trim()
        val confirmPassword = etConfirmPassword.text.toString().trim()
        val acceptedTerms = cbTerms.isChecked

        // Validate inputs
        if (!validateInputs(fullName, email, phone, password, confirmPassword, acceptedTerms)) {
            return
        }

        // Show loading
        btnRegister.isEnabled = false
        btnRegister.text = "Creating Account..."

        // Firebase registration
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Registration success
                    val user = auth.currentUser

                    // Update profile dengan nama lengkap
                    val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                        .setDisplayName(fullName)
                        .build()

                    user?.updateProfile(profileUpdates)?.addOnCompleteListener { profileTask ->
                        // Save additional user data to Firestore
                        saveUserToFirestore(user?.uid, fullName, email, phone)

                        if (profileTask.isSuccessful) {
                            // Profile updated successfully
                            Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()

                            // Go directly to Dashboard (MainActivity)
                            val intent = Intent(this, MainActivity::class.java)
                            startActivity(intent)
                            finish()
                        } else {
                            // Profile update failed, but registration still successful
                            Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()
                            val intent = Intent(this, MainActivity::class.java)
                            startActivity(intent)
                            finish()
                        }
                    }
                } else {
                    // Registration failed
                    btnRegister.isEnabled = true
                    btnRegister.text = "Create Account"
                    Toast.makeText(this, "Registration failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun saveUserToFirestore(userId: String?, fullName: String, email: String, phone: String) {
        userId?.let { uid ->
            val user = hashMapOf(
                "fullName" to fullName,
                "email" to email,
                "phone" to phone,
                "createdAt" to com.google.firebase.Timestamp.now()
            )

            db.collection("users")
                .document(uid)
                .set(user)
                .addOnSuccessListener {
                    println("User data saved to Firestore")
                }
                .addOnFailureListener { e ->
                    println("Error saving user data: $e")
                }
        }
    }

    private fun validateInputs(
        fullName: String,
        email: String,
        phone: String, // TAMBAH INI
        password: String,
        confirmPassword: String,
        acceptedTerms: Boolean
    ): Boolean {
        // Validate full name
        if (ValidationUtils.isFieldEmpty(fullName)) {
            etFullName.error = "Full name is required"
            etFullName.requestFocus()
            return false
        }

        if (!ValidationUtils.isValidName(fullName)) {
            etFullName.error = "Please enter a valid name"
            etFullName.requestFocus()
            return false
        }

        // Validate email
        if (ValidationUtils.isFieldEmpty(email)) {
            etEmail.error = "Email is required"
            etEmail.requestFocus()
            return false
        }

        if (!ValidationUtils.isValidEmail(email)) {
            etEmail.error = "Please enter a valid email"
            etEmail.requestFocus()
            return false
        }

        // Validate phone number - TAMBAH INI
        if (ValidationUtils.isFieldEmpty(phone)) {
            etPhone.error = "Phone number is required"
            etPhone.requestFocus()
            return false
        }

        if (!ValidationUtils.isValidPhone(phone)) {
            etPhone.error = "Please enter a valid phone number"
            etPhone.requestFocus()
            return false
        }

        // Validate password
        if (ValidationUtils.isFieldEmpty(password)) {
            etPassword.error = "Password is required"
            etPassword.requestFocus()
            return false
        }

        if (!ValidationUtils.isValidPassword(password)) {
            etPassword.error = "Password must be at least 6 characters"
            etPassword.requestFocus()
            return false
        }

        // Validate confirm password
        if (ValidationUtils.isFieldEmpty(confirmPassword)) {
            etConfirmPassword.error = "Please confirm your password"
            etConfirmPassword.requestFocus()
            return false
        }

        if (!ValidationUtils.doPasswordsMatch(password, confirmPassword)) {
            etConfirmPassword.error = "Passwords do not match"
            etConfirmPassword.requestFocus()
            return false
        }

        // Validate terms acceptance
        if (!acceptedTerms) {
            Toast.makeText(this, "Please accept the terms and conditions", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }
}