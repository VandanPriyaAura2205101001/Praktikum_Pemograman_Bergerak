package com.example.petbuddy

data class Kesehatan(
    var id: String = "",
    var namaHewan: String = "",
    var jenisPemeriksaan: String = "",
    var tanggal: String = "",
    var keterangan: String = "",
    var userId: String = ""
)
