package com.example.petbuddy.utils

import android.content.Context
import android.content.SharedPreferences

class PrefManager(private val context: Context) {
    private val sharedPref: SharedPreferences = context.getSharedPreferences("PetBuddyPref", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_REMEMBER_ME = "remember_me"
        private const val KEY_IS_FIRST_LAUNCH = "is_first_launch"
    }

    // Remember me functionality
    fun setRememberMe(remember: Boolean) {
        sharedPref.edit().putBoolean(KEY_REMEMBER_ME, remember).apply()
    }

    fun isRememberMe(): Boolean {
        return sharedPref.getBoolean(KEY_REMEMBER_ME, false)
    }

    // First launch
    fun setFirstLaunch(isFirst: Boolean) {
        sharedPref.edit().putBoolean(KEY_IS_FIRST_LAUNCH, isFirst).apply()
    }

    fun isFirstLaunch(): Boolean {
        return sharedPref.getBoolean(KEY_IS_FIRST_LAUNCH, true)
    }

    // Clear all preferences
    fun clearPreferences() {
        sharedPref.edit().clear().apply()
    }
}