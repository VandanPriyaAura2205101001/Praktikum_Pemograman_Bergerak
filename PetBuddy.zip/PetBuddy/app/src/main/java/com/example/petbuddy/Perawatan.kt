package com.example.petbuddy

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Perawatan(
    var id: String? = null,
    var namaHewan: String? = "",
    var jenisPerawatan: String? = "",
    var tanggal: String? = "",
    var keterangan: String? = "",
    val userId: String = "",
    var docId: String? = null
) : Parcelable
