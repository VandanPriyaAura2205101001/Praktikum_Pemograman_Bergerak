package com.example.petbuddy.model

data class User(
    val uid: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val bio: String = "Pengguna PetBuddy yang menyayangi hewan 🐾",
    val profileImage: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    // Convert to Map for Firestore
    fun toMap(): Map<String, Any> {
        return mapOf(
            "uid" to uid,
            "fullName" to fullName,
            "email" to email,
            "phone" to phone,
            "bio" to bio,
            "profileImage" to profileImage,
            "createdAt" to createdAt
        )
    }

    companion object {
        // Create User from Firestore Document
        fun fromMap(map: Map<String, Any>): User {
            return User(
                uid = map["uid"] as? String ?: "",
                fullName = map["fullName"] as? String ?: "",
                email = map["email"] as? String ?: "",
                phone = map["phone"] as? String ?: "",
                bio = map["bio"] as? String ?: "",
                profileImage = map["profileImage"] as? String ?: "",
                createdAt = (map["createdAt"] as? Long) ?: System.currentTimeMillis()
            )
        }
    }
}