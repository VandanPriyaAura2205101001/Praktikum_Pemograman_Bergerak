package com.example.petbuddy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.petbuddy.databinding.ActivityHealthBinding

class HealthActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHealthBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHealthBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Informasi kesehatan kucing
        binding.tvCatHealth.text = """
            • Nafsu makan menurun.
            • Sering muntah atau diare.
            • Bulu rontok berlebihan.
            • Mata berair atau hidung meler.
            • Segera ke dokter hewan jika berlanjut.
        """.trimIndent()

        // Informasi kesehatan anjing
        binding.tvDogHealth.text = """
            • Tidak aktif seperti biasanya.
            • Batuk atau bersin terus-menerus.
            • Luka tidak sembuh.
            • Napas cepat atau tersengal.
            • Bawa ke dokter hewan jika memburuk.
        """.trimIndent()
    }
}
