package com.example.petbuddy

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class TambahPerawatanActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tambah_perawatan)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        val etNamaHewan = findViewById<EditText>(R.id.etNamaHewan)
        val etJenisPerawatan = findViewById<EditText>(R.id.etJenisPerawatan)
        val etTanggal = findViewById<EditText>(R.id.etTanggal)
        val etKeterangan = findViewById<EditText>(R.id.etKeterangan)
        val btnSimpan = findViewById<Button>(R.id.btnSimpanPerawatan)

        btnSimpan.setOnClickListener {

            val userId = auth.currentUser?.uid ?: return@setOnClickListener

            val perawatan = Perawatan(
                namaHewan = etNamaHewan.text.toString(),
                jenisPerawatan = etJenisPerawatan.text.toString(),
                tanggal = etTanggal.text.toString(),
                keterangan = etKeterangan.text.toString(),
                userId = userId    // tambahkan userId
            )

            // === SIMPAN KE FIRESTORE ===
            db.collection("perawatan")
                .add(perawatan)
                .addOnSuccessListener {
                    // kirim balik ke PerawatanActivity
                    val resultIntent = intent
                    resultIntent.putExtra("perawatan", perawatan)
                    setResult(Activity.RESULT_OK, resultIntent)
                    finish()
                }
                .addOnFailureListener {
                    // supaya tidak crash
                    setResult(Activity.RESULT_CANCELED)
                    finish()
                }
        }
    }
}
