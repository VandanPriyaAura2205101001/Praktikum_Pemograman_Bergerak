package com.example.petbuddy

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class PerawatanAdapter(private val perawatanList: MutableList<Perawatan>) :
    RecyclerView.Adapter<PerawatanAdapter.PerawatanViewHolder>() {

    private val db = FirebaseFirestore.getInstance()

    inner class PerawatanViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNamaHewan: TextView = itemView.findViewById(R.id.tvNamaHewan)
        val tvJenisPerawatan: TextView = itemView.findViewById(R.id.tvJenisPerawatan)
        val tvTanggal: TextView = itemView.findViewById(R.id.tvTanggal)
        val tvKeterangan: TextView = itemView.findViewById(R.id.tvKeterangan)

        // 🔥 HANYA DIGANTI TIPE-NYA, tidak ubah logika
        val btnHapus: Button = itemView.findViewById(R.id.btnHapus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PerawatanViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_perawatan, parent, false)
        return PerawatanViewHolder(view)
    }

    override fun onBindViewHolder(holder: PerawatanViewHolder, position: Int) {
        val perawatan = perawatanList[position]
        holder.tvNamaHewan.text = perawatan.namaHewan
        holder.tvJenisPerawatan.text = perawatan.jenisPerawatan
        holder.tvTanggal.text = perawatan.tanggal
        holder.tvKeterangan.text = perawatan.keterangan

        // Tombol hapus
        holder.btnHapus.setOnClickListener {
            val id = perawatan.id ?: return@setOnClickListener

            db.collection("perawatan").document(id)
                .delete()
                .addOnSuccessListener {
                    perawatanList.removeAt(position)
                    notifyItemRemoved(position)
                    notifyItemRangeChanged(position, perawatanList.size)
                }
        }
    }

    override fun getItemCount(): Int = perawatanList.size
}
