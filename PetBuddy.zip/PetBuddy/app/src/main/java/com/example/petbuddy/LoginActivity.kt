package com.example.petbuddy

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.petbuddy.utils.ValidationUtils
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText

    private lateinit var btnLogin: Button
    private lateinit var tvRegister: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Cek apakah user sudah login
        auth = FirebaseAuth.getInstance()
        if (auth.currentUser != null) {
            // User sudah login, langsung ke Dashboard
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_login)

        // Initialize views
        initViews()

        // Set click listeners
        setupClickListeners()
    }

    private fun initViews() {
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        tvRegister = findViewById(R.id.tvRegister)
    }

    private fun setupClickListeners() {
        btnLogin.setOnClickListener {
            loginUser()
        }

        tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun loginUser() {
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()

        // Validate inputs
        if (!validateInputs(email, password)) {
            return
        }

        // Show loading
        btnLogin.isEnabled = false
        btnLogin.text = "Logging in..."

        // Firebase authentication
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                btnLogin.isEnabled = true
                btnLogin.text = "Login"

                if (task.isSuccessful) {
                    // Login success
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()

                    // Go directly to Dashboard (MainActivity)
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    // Login failed
                    Toast.makeText(
                        this,
                        "Login failed: ${task.exception?.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
    }

    private fun validateInputs(email: String, password: String): Boolean {
        // Validate email
        if (ValidationUtils.isFieldEmpty(email)) {
            etEmail.error = "Email is required"
            etEmail.requestFocus()
            return false
        }

        if (!ValidationUtils.isValidEmail(email)) {
            etEmail.error = "Please enter a valid email"
            etEmail.requestFocus()
            return false
        }

        // Validate password
        if (ValidationUtils.isFieldEmpty(password)) {
            etPassword.error = "Password is required"
            etPassword.requestFocus()
            return false
        }

        if (!ValidationUtils.isValidPassword(password)) {
            etPassword.error = "Password must be at least 6 characters"
            etPassword.requestFocus()
            return false
        }

        return true
    }
}
