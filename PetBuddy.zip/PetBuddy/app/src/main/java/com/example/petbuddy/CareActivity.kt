package com.example.petbuddy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class CareActivity : AppCompatActivity() {

    private lateinit var tvCatCare: TextView
    private lateinit var tvDogCare: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_care)

        tvCatCare = findViewById(R.id.tvCatCare)
        tvDogCare = findViewById(R.id.tvDogCare)

        tvCatCare.text = """
            • Mandi 1–2 minggu sekali.
            • Sisir bulu setiap hari.
            • Berikan makanan khusus kucing.
            • Bersihkan mata & telinga secara rutin.
            • Vaksin minimal sekali setahun.
        """.trimIndent()

        tvDogCare.text = """
            • Mandi 1 minggu sekali.
            • Ajak jalan setiap hari.
            • Potong kuku 1–2 bulan sekali.
            • Berikan makanan khusus anjing (dog food).
            • Vaksin & periksa kesehatan rutin.
        """.trimIndent()
    }
}
