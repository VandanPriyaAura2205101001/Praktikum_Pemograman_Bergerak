package com.example.petbuddy.menu

class main_menu {
}