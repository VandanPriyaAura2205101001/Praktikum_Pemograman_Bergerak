package com.example.petbuddy

import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.firestore.FirebaseFirestore

class PerawatanActivity : AppCompatActivity() {

    private val perawatanList = mutableListOf<Perawatan>()
    private lateinit var adapter: PerawatanAdapter
    private val db = FirebaseFirestore.getInstance()

    private val addPerawatanLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val perawatanBaru = result.data?.getParcelableExtra<Perawatan>("perawatan")
            if (result.resultCode == RESULT_OK) {
                loadDataPerawatan()  // cukup refresh saja
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perawatan)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewPerawatan)
        adapter = PerawatanAdapter(perawatanList)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        val fabTambah = findViewById<FloatingActionButton>(R.id.fabTambahPerawatan)
        fabTambah.setOnClickListener {
            addPerawatanLauncher.launch(Intent(this, TambahPerawatanActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        loadDataPerawatan()   // <-- WAJIB agar daftar langsung berubah ketika kembali
    }

    private fun loadDataPerawatan() {
        db.collection("perawatan")
            .get()
            .addOnSuccessListener { result ->
                perawatanList.clear()
                for (doc in result) {
                    val data = doc.toObject(Perawatan::class.java)
                    data.id = doc.id
                    perawatanList.add(data)
                }
                adapter.notifyDataSetChanged()
            }
    }
}
