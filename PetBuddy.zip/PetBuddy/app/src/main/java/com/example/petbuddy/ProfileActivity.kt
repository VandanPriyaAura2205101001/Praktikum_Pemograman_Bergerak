package com.example.petbuddy

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage

class ProfileActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var ivProfile: ImageView
    private lateinit var tvFullName: TextView
    private lateinit var tvEmail: TextView
    private lateinit var tvPhone: TextView
    private lateinit var btnLogout: Button
    private lateinit var btnBack: ImageButton
    private lateinit var btnEditProfile: Button

    private val db = Firebase.firestore
    private val storage = Firebase.storage

    private var selectedImageUri: Uri? = null

    // Launcher pilih gambar
    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                selectedImageUri = result.data?.data
                ivProfile.setImageURI(selectedImageUri) // tampilkan lokal dulu
                uploadProfileImage() // terus upload
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        auth = Firebase.auth

        initViews()
        setupUserInfo()
        setupClickListeners()
    }

    private fun initViews() {
        ivProfile = findViewById(R.id.ivProfile)
        tvFullName = findViewById(R.id.tvFullName)
        tvEmail = findViewById(R.id.tvEmail)
        tvPhone = findViewById(R.id.tvPhone)
        btnLogout = findViewById(R.id.btnLogout)
        btnBack = findViewById(R.id.btnBack)
        btnEditProfile = findViewById(R.id.btnEditProfile)
    }

    private fun setupUserInfo() {
        val currentUser = auth.currentUser ?: return

        tvEmail.text = currentUser.email ?: "No email"

        getUserDataFromFirestore(currentUser.uid)
    }

    private fun getUserDataFromFirestore(userId: String) {
        db.collection("users").document(userId).get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) {
                    val fullName = doc.getString("fullName") ?: "Unknown"
                    val phone = doc.getString("phone") ?: "Not set"
                    val imageUrl = doc.getString("profileImageUrl")

                    tvFullName.text = fullName
                    tvPhone.text = phone

                    // tampilkan foto dari Firebase Storage
                    if (!imageUrl.isNullOrEmpty()) {
                        Glide.with(this)
                            .load(imageUrl)
                            .placeholder(android.R.drawable.ic_menu_gallery)
                            .into(ivProfile)
                    }
                }
            }
    }

    private fun setupClickListeners() {

        // klik foto → buka galeri
        ivProfile.setOnClickListener {
            openGallery()
        }

        btnLogout.setOnClickListener {
            auth.signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        btnBack.setOnClickListener {
            onBackPressed()
        }

        btnEditProfile.setOnClickListener {
            startActivity(Intent(this, EditProfileActivity::class.java))
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        pickImageLauncher.launch(intent)
    }

    private fun uploadProfileImage() {
        val user = auth.currentUser ?: return
        val uri = selectedImageUri ?: return

        val storageRef = storage.reference.child("profile_images/${user.uid}.jpg")

        storageRef.putFile(uri)
            .addOnSuccessListener {
                storageRef.downloadUrl.addOnSuccessListener { downloadUrl ->
                    saveImageUrlToFirestore(downloadUrl.toString())
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Upload gagal: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }


    private fun saveImageUrlToFirestore(url: String) {
        val user = auth.currentUser ?: return

        db.collection("users")
            .document(user.uid)
            .update("profileImageUrl", url)
            .addOnSuccessListener {
                Toast.makeText(this, "Foto profil berhasil diperbarui!", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Gagal menyimpan URL", Toast.LENGTH_SHORT).show()
            }
    }
}
