package com.example.petbuddy

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PetDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pet_detail)

        val imgPet = findViewById<ImageView>(R.id.imgPetDetail)
        val txtName = findViewById<TextView>(R.id.txtPetName)
        val txtDesc = findViewById<TextView>(R.id.txtPetDesc)

        val name = intent.getStringExtra("petName")
        val desc = intent.getStringExtra("petDesc")
        val image = intent.getIntExtra("petImage", 0)

        txtName.text = name
        txtDesc.text = desc
        imgPet.setImageResource(image)
    }
}
