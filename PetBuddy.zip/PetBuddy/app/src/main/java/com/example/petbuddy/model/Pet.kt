package com.example.petbuddy.model

data class Pet(
    val name: String,
    val description: String,
    val imageRes: Int
)
