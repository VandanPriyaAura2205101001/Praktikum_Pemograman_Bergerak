package com.example.petbuddy

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class KesehatanAdapter(
    private val list: MutableList<Kesehatan>
) : RecyclerView.Adapter<KesehatanAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvNama: TextView = view.findViewById(R.id.tvNamaHewan)
        val tvJenis: TextView = view.findViewById(R.id.tvJenisPemeriksaan)
        val tvTanggal: TextView = view.findViewById(R.id.tvTanggal)
        val tvKet: TextView = view.findViewById(R.id.tvKeterangan)
        val btnHapus: Button = view.findViewById(R.id.btnHapus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_kesehatan, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = list[position]

        holder.tvNama.text = "Hewan: ${data.namaHewan}"
        holder.tvJenis.text = "Pemeriksaan: ${data.jenisPemeriksaan}"
        holder.tvTanggal.text = "Tanggal: ${data.tanggal}"
        holder.tvKet.text = "Catatan: ${data.keterangan}"

        holder.btnHapus.setOnClickListener {
            FirebaseFirestore.getInstance()
                .collection("kesehatan")
                .document(data.id)
                .delete()

            list.removeAt(position)
            notifyItemRemoved(position)
        }
    }
}
