package com.example.petbuddy

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class TambahHewanActivity : AppCompatActivity() {

    private lateinit var edtName: EditText
    private lateinit var edtType: EditText
    private lateinit var btnSave: Button

    private val db = FirebaseFirestore.getInstance()
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tambah_hewan)

        auth = FirebaseAuth.getInstance()

        edtName = findViewById(R.id.edtName)
        edtType = findViewById(R.id.edtType)
        btnSave = findViewById(R.id.btnSave)

        btnSave.setOnClickListener {
            savePet()
        }
    }

    private fun savePet() {
        val user = auth.currentUser ?: return

        val name = edtName.text.toString().trim()
        val type = edtType.text.toString().trim()

        if (name.isEmpty()) {
            edtName.error = "Nama hewan wajib diisi"
            return
        }

        val petData = hashMapOf(
            "name" to name,
            "type" to type
        )

        db.collection("users")
            .document(user.uid)
            .collection("pets")
            .add(petData)
            .addOnSuccessListener {
                Toast.makeText(this, "Hewan berhasil ditambahkan", Toast.LENGTH_SHORT).show()
                finish()
            }
    }
}
