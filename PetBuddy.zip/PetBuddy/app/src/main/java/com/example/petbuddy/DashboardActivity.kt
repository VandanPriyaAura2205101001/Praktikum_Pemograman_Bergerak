package com.example.petbuddy

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.petbuddy.CareActivity
import com.example.petbuddy.databinding.ActivityDashboardBinding
import com.example.petbuddy.HealthActivity
import com.example.petbuddy.PetListActivity
import com.example.petbuddy.ProfileActivity

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.menuPetData.setOnClickListener {
            startActivity(Intent(this, PetListActivity::class.java)) // DATA HEWAN
        }

        binding.menuCare.setOnClickListener {
            startActivity(Intent(this, CareActivity::class.java)) // PERAWATAN
        }

        binding.menuHealth.setOnClickListener {
            startActivity(Intent(this, HealthActivity::class.java)) // KESEHATAN
        }

        binding.menuProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java)) // PROFIL
        }
    }
}
